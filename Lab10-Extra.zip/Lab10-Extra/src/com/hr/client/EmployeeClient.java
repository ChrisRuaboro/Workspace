package com.hr.client;

import com.hr.Employee;

public class EmployeeClient {

    public static void main(String[] args) {
        // TODO: create an instance of Employee

        // TODO: call goToWork() on the Employee object

    }
}
