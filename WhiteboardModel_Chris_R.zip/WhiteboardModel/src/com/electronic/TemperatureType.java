package com.electronic;

public enum TemperatureType
{
    CELSIUS, FAHRENHEIT, KELVIN
}
